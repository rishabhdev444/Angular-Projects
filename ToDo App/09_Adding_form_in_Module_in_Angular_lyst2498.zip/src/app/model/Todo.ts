export interface Todo {
  id: string;
  title: string;
  isCompleted: boolean;
  date: Date;
}
